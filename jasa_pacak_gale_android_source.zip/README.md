# Jasa Pacak Gale Pangkalpinang — Android starter project

Project Android native (Kotlin + WebView) untuk aplikasi pemesanan Jasa Pacak Gale.
Nomor WhatsApp admin: 083183855890.

## Fitur
- Antar jemput
- Jastip makanan
- Jastip barang
- Pengantaran barang
- Layanan express
- Form alamat jemput, alamat tujuan, catatan, dan estimasi jarak
- Estimasi ongkir berdasarkan jarak
- Pesanan diteruskan ke WhatsApp admin

## Penting
Ini adalah source project Android, bukan APK yang sudah dikompilasi. APK perlu dibuild dengan Android Studio dan Android SDK.

## Cara build
1. Buka Android Studio.
2. Pilih **Open** lalu pilih folder `jasa_pacak_gale_android`.
3. Tunggu Gradle sync. Android Studio mungkin meminta Gradle/Android plugin menyesuaikan versi yang tersedia.
4. Pilih **Build > Build APK(s)**.
5. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Tarif
Tarif awal bisa diubah di `app/src/main/java/com/pacakgale/app/MainActivity.kt`, fungsi `calculateFare()`.
Default: Rp3.000 per kilometer, minimum Rp10.000, maksimum tarif reguler Rp20.000 di area Pangkalpinang. Express dikenakan tambahan Rp5.000. Ini adalah nilai awal yang dapat diubah sebelum dipakai usaha.
