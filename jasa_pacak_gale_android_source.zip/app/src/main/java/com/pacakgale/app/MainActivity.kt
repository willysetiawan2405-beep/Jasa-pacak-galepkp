package com.pacakgale.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.view.Gravity
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.text.InputType
import java.net.URLEncoder
import java.util.Locale
import kotlin.math.ceil

class MainActivity : Activity() {
    private val whatsappNumber = "6283183855890"
    private val navy = Color.rgb(16, 42, 67)
    private val amber = Color.rgb(245, 158, 11)
    private val pale = Color.rgb(245, 248, 251)
    private lateinit var service: Spinner
    private lateinit var pickup: EditText
    private lateinit var destination: EditText
    private lateinit var distance: EditText
    private lateinit var notes: EditText
    private lateinit var fareText: TextView
    private lateinit var expressCheck: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(25), dp(22), dp(22))
            setBackgroundColor(navy)
        }
        header.addView(TextView(this).apply {
            text = "JASA PACAK GALE"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        header.addView(TextView(this).apply {
            text = "PANGKALPINANG  •  Cepat, praktis, terpercaya"
            textSize = 13f
            setTextColor(Color.rgb(255, 218, 140))
            setPadding(0, dp(6), 0, 0)
        })
        root.addView(header)

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(24))
        }
        scroll.addView(content)
        content.addView(label("Pesan layanan", 21f, navy, true))
        content.addView(label("Pilih layanan yang kamu butuhkan.", 14f, Color.DKGRAY, false))
        content.addView(label("Jenis layanan", 14f, navy, true))
        service = Spinner(this)
        val services = listOf("Antar jemput", "Jastip makanan/minuman", "Jastip barang", "Pengantaran barang", "Layanan express")
        service.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, services)
        content.addView(service, matchWrap())
        pickup = field("Alamat penjemputan / lokasi kamu")
        content.addView(label("Alamat penjemputan", 14f, navy, true))
        content.addView(pickup, matchWrap())
        destination = field("Alamat tujuan / lokasi toko")
        content.addView(label("Alamat tujuan", 14f, navy, true))
        content.addView(destination, matchWrap())
        distance = field("Contoh: 3.5")
        distance.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        content.addView(label("Perkiraan jarak (km)", 14f, navy, true))
        content.addView(distance, matchWrap())
        content.addView(label("Tarif dihitung dari jarak yang kamu masukkan. Pastikan jarak sesuai rute perjalanan.", 12f, Color.DKGRAY, false))
        expressCheck = CheckBox(this).apply {
            text = "Prioritas express (+Rp5.000)"
            setTextColor(navy)
        }
        content.addView(expressCheck)
        notes = field("Detail pesanan, nama makanan/barang, patokan alamat, dll.")
        notes.minLines = 3
        notes.gravity = Gravity.TOP
        content.addView(label("Catatan pesanan", 14f, navy, true))
        content.addView(notes, matchWrap())
        fareText = TextView(this).apply {
            text = "Estimasi ongkir: masukkan jarak"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(navy)
            setPadding(dp(14), dp(15), dp(14), dp(15))
            setBackgroundColor(Color.rgb(255, 241, 204))
        }
        content.addView(fareText, matchWrap())
        val calc = Button(this).apply {
            text = "Hitung Estimasi Ongkir"
            setOnClickListener { updateFare() }
        }
        content.addView(calc, matchWrap())
        val order = Button(this).apply {
            text = "Pesan via WhatsApp"
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(amber))
            setTextColor(navy)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { sendOrder() }
        }
        content.addView(order, matchWrap())
        content.addView(TextView(this).apply {
            text = "Tarif awal: Rp3.000/km, minimum Rp10.000, maksimum reguler Rp20.000 untuk area Pangkalpinang. Express +Rp5.000. Konfirmasi tarif akhir kepada admin sebelum perjalanan."
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(12), 0, 0)
        })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(10), 0, dp(5))
        }

    private fun field(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setSingleLine(false)
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(Color.WHITE)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(5) }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun calculateFare(): Int? {
        val km = distance.text.toString().trim().replace(',', '.').toDoubleOrNull() ?: return null
        if (km <= 0 || km > 500) return null
        var fare = maxOf(10000, ceil(km).toInt() * 3000)
        fare = minOf(fare, 20000)
        if (expressCheck.isChecked || service.selectedItem.toString().contains("express", true)) fare += 5000
        return fare
    }

    private fun updateFare() {
        val fare = calculateFare()
        fareText.text = if (fare == null) "Masukkan jarak yang valid (mis. 3.5 km)" else
            "Estimasi ongkir: " + rupiah(fare)
    }

    private fun sendOrder() {
        val p = pickup.text.toString().trim()
        val d = destination.text.toString().trim()
        val km = distance.text.toString().trim()
        if (p.isEmpty() || d.isEmpty() || km.isEmpty()) {
            Toast.makeText(this, "Isi alamat jemput, alamat tujuan, dan jarak terlebih dahulu.", Toast.LENGTH_LONG).show()
            return
        }
        val fare = calculateFare()
        if (fare == null) {
            Toast.makeText(this, "Masukkan jarak yang valid.", Toast.LENGTH_LONG).show()
            return
        }
        val message = """
            Halo Jasa Pacak Gale Pangkalpinang, saya ingin memesan layanan.

            Layanan: ${service.selectedItem}
            Alamat jemput: $p
            Alamat tujuan: $d
            Perkiraan jarak: $km km
            Estimasi ongkir: ${rupiah(fare)}
            Catatan: ${notes.text.toString().trim().ifEmpty { "-" }}

            Mohon konfirmasi ketersediaan dan total biaya. Terima kasih.
        """.trimIndent()
        val url = "https://wa.me/$whatsappNumber?text=" + URLEncoder.encode(message, "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "WhatsApp atau browser tidak tersedia.", Toast.LENGTH_LONG).show()
        }
    }

    private fun rupiah(value: Int): String =
        String.format(Locale("in", "ID"), "Rp%,d", value).replace(',', '.')
}
